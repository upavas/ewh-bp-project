Running the serial BP PCB board on windows (Instructions):

1 - Attach the device to the PC (windows OS);
2 - If the host is a PC and this is the first time you have plugged this device into the computer then you may be asked for a .inf file.
3 - Select the �Install from a list or specific location (Advanced)� option and then �Include this location in the search�.
4 - Point to the �<Extracted Directory>\Windows Drivers� directory
5 - While installing drivers, if a non-recognised manufacturer warning appears, select �Continue Anyway�.